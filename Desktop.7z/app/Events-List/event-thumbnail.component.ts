import { Component, Input, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
    selector: "event-thumbnail",
    template: `
    
<div class="well hoverwell thumbnail">
<h3>{{event.name}}</h3>
<div>Date: {{event.date}}</div>
<div>Time: {{event.time}}</div>
<div>Price: \${{event.price}}</div>
<div>Location: {{event.location.address}}
    <span>{{event.location.city}}</span>
    <span>, </span>
    <span>{{event.location.country}}</span>
</div>
</div>
    `,
})

export class EventThumbnailComponent{
   
    @Input() event:any;
}